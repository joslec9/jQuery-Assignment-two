$(document).ready(function() {
	
			$('#ninja1').click(function() {
				$(this).hide();
			})
			
			$('#ninja2').click(function() {
				$(this).hide();
			})
			
			$('#ninja3').click(function() {
				$(this).hide();
			})
			
			$('#ninja4').click(function() {
				$(this).hide();
			})
			
			$('#ninja5').click(function() {
				$(this).hide();
			})
			
			$('#ninja6').click(function() {
				$(this).hide();
			})
			
			$('#ninja7').click(function() {
				$(this).hide();
			})
			
			$('#ninja8').click(function() {
				$(this).hide();
			})

			$('button').click(function() {
				$('img').show();
			})
		})