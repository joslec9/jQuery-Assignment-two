# Coding Dojo Project Assignment two
### Author: Jose Lechuga

## Disappearing Ninja
Create a simple HTML page with 8 images of equal width and height (you can use any image you like). When a particular image is clicked, have that image disappear. Also, include a button on the bottom of the page called 'Restore'. When the button is clicked, all images will appear.


The image used in this project is provided by (http://w10.naukri.com/mailers/2014/firstnaukri/ninja8sep/images/top1.jpg)
